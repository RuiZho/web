import os
import threading
import time
from socket import *
import sh
import json
from multiprocessing import Process
import queue
import shutil
import sys

class Worker:
    def __init__ (self, master_port, worker_port):
        self.master_port = master_port
        self.worker_port = worker_port


        #get pid
        pid = os.getpid()
        self.pid = pid

        #register
        data1 = {
            "message_type" : "register",
            "worker_host" : "localhost",
            "worker_port" : self.worker_port,
            "worker_pid" : pid
        }
        msg = json.dumps(data1)
        # Send the data to the port that master is on
        try:
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect(("localhost", master_port))
            sock.setblocking(0)
            sock.sendall(str.encode(msg))
            sock.close()
        except error:
            print("Failed to send register to master.")

        # createt listen as a thread?
        #tcp on worker_port, socket.SOCK_DGRAM is UDP,
        s = socket(AF_INET, SOCK_STREAM)
        # NOTE: use socket.gethostname() if you want server to listen on 0.0.0.0
        s.bind(("localhost", worker_port))
        s.listen(5)

        while True:
            client_socket, address = s.accept()
            message = ""
            while True:
                data = client_socket.recv(4096)
                message += data.decode("utf-8")
                if len(data) == 0:
                    client_socket.close()
                    break
                elif len(data) != 4096:
                    client_socket.close()
                    break
            #print(message)
            self.handle_msg(message = message)


    def handle_msg(self, message):
        data = json.loads(message)
        if (data["message_type"] == "register_ack"):
        	hb = threading.Thread(target=self.heartbeat, kwargs={'msg': data})
        	hb.start()
        elif (data["message_type"] == "new_worker_job"):
            print("new_worker_job", data)
            out_files = []
            for files in data["input_files"]:
                basename = os.path.basename(files)
                out_files.append(os.path.join(data["output_directory"], basename))
                exe=sh.Command(data["executable"])
                f = open(files, 'r')
                outname = os.path.join(data["output_directory"], basename)
                exe(_in=f, _out= outname)
                f.close()
                #close undone
            new_data = {
                "message_type": "status",
                "output_files" : out_files,
                "status": "finished",
                "worker_pid": self.pid
            }
            message = json.dumps(new_data)
            # Send the data to the port that master is on
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", self.master_port))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send finished job to master.")
        elif (data["message_type"] == "new_sort_job"):
            #undone sort job
            outfile = data["output_file"]
            print("new_sort_job", data)
            with open (outfile, 'w+') as o:
                for files in data["input_files"]:
                    with open(files) as infile:
                        for line in infile:
                            o.write(line)
            with open(outfile, 'r') as o1:
                tmp = sorted(o1)
            with open(outfile, 'w+') as o2:
                o2.writelines(tmp)
            #send back
            new_data = {
                "message_type": "status",
                "output_file" : outfile,
                "status": "finished",
                "worker_pid": self.pid
            }
            message = json.dumps(new_data)
            # Send the data to the port that master is on
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", self.master_port))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send finished group job to master.")


        elif (data["message_type"] == "shutdown"):
            print("worker: shutdown received.")
            sys.exit(0)

    def heartbeat(self,msg):
        data = {
            "message_type": "heartbeat",
            "worker_pid": self.pid
        }
        message = str.encode(json.dumps(data))
        s = socket(AF_INET, SOCK_DGRAM)
        while True:
            s.sendto(message,("localhost",self.master_port-1)) #masterport -1??
            time.sleep(2)

if __name__ == '__main__':
    p = Process(target=Worker, args=(int(sys.argv[1]),int(sys.argv[2]),))
    p.start()

	#Worker(6000,6001)

	#Worker(6000,6002)
