import os
import threading
import time
from socket import *
import sh
import json
from multiprocessing import Process
import queue
import shutil
import sys
import copy


class Master:
    def __init__ (self, port_number):
        self.port_number = port_number
        self.busy_list = dict() #key:worker_id, value:jobs
        self.dead_list = [] #worker_id
        self.ready_list = [] #include id
        self.worker_status = dict() #key:worker_id, value:ready/busy/dead/register
        self.port_list = dict()
        self.hb_record = dict() #workerid, last_hb_time
        self.counter = 0
        self.job_queue = queue.Queue()
        self.master_status = "ready"
        self.shutdown = False
        self.current_job = None #json info from new_master_job + job_counter
        #new folder
        folder = "var"
        #os.path
        if (os.path.isdir(folder)):
            shutil.rmtree(folder)
        os.mkdir(folder)

        #heartbeat
        t = threading.Thread(target=self.master_heartbeat ,args=(port_number-1,)) #,?
        t.start()
        #fault check
        t1 = threading.Thread(target=self.fault_tolerance) #,?
        t1.start()

        #tcp
        s = socket(AF_INET, SOCK_STREAM)
        # NOTE: use socket.gethostname() if you want server to listen on 0.0.0.0
        s.bind(("localhost", port_number))
        s.listen(5)
        while True:
            client_socket, address = s.accept()
            message = ""
            while True:
                data = client_socket.recv(4096)
                message += data.decode("utf-8")
                if len(data) == 0:
                    client_socket.close()
                    break
                elif len(data) != 4096:
                    client_socket.close()
                    break

            self.handle_msg(message = message)

    def mapping (self, data):
        self.master_status = "mapping"
        self.current_job = data
        mapper = data["num_mappers"]
        worker_num = 0
        ready_list = []
        for x in self.worker_status:
            if (self.worker_status[x] == "ready" or self.worker_status[x] == "register"):
                ready_list.append(x)
                worker_num = worker_num + 1
        input_files=dict()
        file_count = 0;
        for x in range(0, mapper):
            input_files[x] = []
        #number of tasks
        for file_name in os.listdir(data["input_directory"]):
            if (os.path.isfile(os.path.join(data["input_directory"], file_name))):
                input_files[int(file_count%mapper)].append(os.path.join(data["input_directory"], file_name))
                file_count += 1
        #distribute task to workers
        for x in range(0, mapper):
            current_worker = x % worker_num
            work_id = ready_list[current_worker]
            new_data = {
                "message_type": "new_worker_job",
                "input_files": input_files[x],
                "executable": data["mapper_executable"],
                "output_directory": "var/job-%d/mapper-output" %(self.current_job["counter"]),
                "worker_pid": work_id
            }
            message = json.dumps(new_data)
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", self.port_list[work_id]))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send job to worker.")

            if (work_id not in self.busy_list):
                self.busy_list[work_id] = []
                self.busy_list[work_id].append(new_data)
            else:
                self.busy_list[work_id].append(new_data)
            self.worker_status[work_id] = "busy"

    def grouping (self, data):
        self.master_status = "grouping"
        worker_num = 0
        ready_list = []
        for x in self.worker_status:
            if (self.worker_status[x] == "ready" or self.worker_status[x] == "register"):
                ready_list.append(x)
                worker_num = worker_num + 1
        map_out = os.path.join('var/job-' + str(self.current_job["counter"]) , 'mapper-output/')
        group_out = os.path.join('var/job-' + str(self.current_job["counter"]) , 'grouper-output/')
        #send to workers
        input_files = dict()
        file_count = 0;
        for x in range(0, worker_num):
            input_files[x] = []
        #number of tasks
        for file_name in os.listdir(map_out):
            if (os.path.isfile(os.path.join(map_out, file_name))):
                input_files[int(file_count%worker_num)].append(os.path.join(map_out, file_name))
                file_count += 1
        #distribute task to workers
        for x in range(0, worker_num):
            current_worker = x
            work_id = ready_list[current_worker]
            filename = "group_%d" %x
            new_data = {
                "message_type": "new_sort_job",
                "input_files": input_files[x],
                "output_file": os.path.join(group_out, filename),
                "worker_pid": work_id
            }
            message = json.dumps(new_data)
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", self.port_list[work_id]))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send group job to worker.")

            if (work_id not in self.busy_list):
                self.busy_list[work_id] = []
                self.busy_list[work_id].append(new_data)
            else:
                self.busy_list[work_id].append(new_data)
            self.worker_status[work_id] = "busy"



    def reducing (self, files):
        self.master_status = "reducing"
        reduce_out = os.path.join('var/job-' + str(self.current_job["counter"]), 'reducer-output')
        reducers = self.current_job["num_reducers"]
        worker_num = 0
        ready_list = []
        for x in self.worker_status:
            if (self.worker_status[x] == "ready" or self.worker_status[x] == "register"):
                ready_list.append(x)
                worker_num = worker_num + 1
        for x in range(0, reducers):
            current_worker = x % worker_num
            work_id = ready_list[current_worker]
            new_data = {
                "message_type": "new_worker_job",
                "input_files": files[x],
                "executable": self.current_job["reducer_executable"],
                "output_directory": "var/job-%d/reducer-output" %(self.current_job["counter"]),
                "worker_pid": work_id
            }
            message = json.dumps(new_data)
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", self.port_list[work_id]))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send reduce job to worker.")

            if (work_id not in self.busy_list):
                self.busy_list[work_id] = []
                self.busy_list[work_id].append(new_data)
            else:
                self.busy_list[work_id].append(new_data)
            self.worker_status[work_id] = "busy"


    def handle_msg(self, message):
        data = json.loads(message)
        if (data["message_type"] == "register"):
            print(data["worker_pid"],"registered")

            msg = {
                "message_type" : "register_ack",
                "worker_host" : "localhost",
                "worker_port" : data["worker_port"],
                "worker_pid" : data["worker_pid"]
            }
            message = json.dumps(msg)
            # Send the data to the port that master is on
            try:
                sock = socket(AF_INET, SOCK_STREAM)
                sock.connect(("localhost", data["worker_port"]))
                sock.setblocking(0)
                sock.sendall(str.encode(message))
                sock.close()
            except error:
                print("Failed to send register_ack to worker.")

            worker_id = data["worker_pid"]
            self.worker_status[worker_id] = "register"
            self.port_list[worker_id] = data["worker_port"]
            if (self.master_status == "ready" and self.job_queue.empty()==False):
                job_data = self.job_queue.get()
                self.mapping(data = job_data)

        elif (data["message_type"] == "new_master_job"):
            print("new_master_job received")
            tmp = "var/job-" + str(self.counter)
            os.mkdir(tmp)
            os.mkdir(os.path.join(tmp, 'mapper-output'))
            os.mkdir(os.path.join(tmp, 'grouper-output'))
            os.mkdir(os.path.join(tmp, 'reducer-output'))
            tmp_data = data
            tmp_data["counter"] = self.counter
            self.counter += 1
            num_ready = 0
            for x in self.worker_status:
                if (self.worker_status[x] == "ready" or self.worker_status[x] == "register"):
                    num_ready = num_ready + 1
            if (num_ready != 0 and self.master_status == "ready" and self.job_queue.empty()==True):
                self.mapping(data = tmp_data)
            else:
                self.job_queue.put(tmp_data)
        elif (data["message_type"] == "status"):
            if (data["status"] == "finished"):

                worker_id = data["worker_pid"]
                print(worker_id, "finished")
                if (len(self.busy_list[worker_id]) == 1):
                    del self.busy_list[worker_id]
                else:
                    for tmp in self.busy_list[worker_id]:
                        if tmp["message_type"] == "new_sort_job" and "output_file" in data :
                            self.busy_list[worker_id].remove(tmp)
                        else:
                            tmp_out = os.path.basename(data["output_files"][0])
                            tmp_in = os.path.basename(tmp["input_files"][0])
                            if tmp_out == tmp_in:
                                self.busy_list[worker_id].remove(tmp)

                if worker_id not in self.busy_list:
                    self.worker_status[worker_id] = "ready"
                num_busy = 0
                for x in self.worker_status:
                    if self.worker_status[x] == "busy":
                        num_busy = num_busy +1
                if (num_busy == 0 and self.master_status == "mapping"):
                	self.grouping(data = data)
                elif (num_busy == 0 and self.master_status == "reducing"):
                    if (os.path.isdir(self.current_job["output_directory"])):
                        shutil.rmtree(self.current_job["output_directory"])
                    #if (!os.path.isdir(self.current_job["output_directory"])):
                        #os.makedirs(self.current_job["output_directory"])

                    shutil.copytree(os.path.join('var/job-' + str(self.current_job["counter"]), 'reducer-output'), self.current_job["output_directory"])
                    num_ready = 0
                    for x in self.worker_status:
                        if (self.worker_status[x] == "ready" or self.worker_status[x] == "register"):
                            num_ready = num_ready + 1
                    if (self.job_queue.empty()==False and num_ready != 0):
                        tmp_job = self.job_queue.get()
                        self.mapping(data = tmp_job)
                    else:
                        self.master_status = "ready"
                elif (num_busy == 0 and self.master_status == "grouping"):
                    #worker finished sorting file
                    out_dir = os.path.join('var/job-' + str(self.current_job["counter"]) , 'grouper-output/')
                    outfile = os.path.join(out_dir, "final")
                    with open (outfile, 'w+') as o:
                        for files in os.listdir(out_dir):
                            if (files != "final"):
                                with open(os.path.join(out_dir, files),'r') as infile:
                                    for line in infile:
                                        o.write(line)
                    with open(outfile, 'r') as o1:
                        tmp = sorted(o1)
                    with open(outfile, 'w+') as o2:
                        o2.writelines(tmp)
                    #distribute by keys
                    for files in os.listdir(out_dir):
                        if (files != "final"):
                            os.remove(os.path.join(out_dir, files))
                    reducers = self.current_job["num_reducers"]
                    reducer_files = dict()
                    red_dir = os.path.join('var/job-' + str(self.current_job["counter"]), 'grouper-output/')
                    for i in range(0,reducers):
                        reducer_files[i] = []
                        name = "input_%d" %i
                        filename = os.path.join(red_dir, name)
                        open(filename, 'w').close()
                        reducer_files[i].append(filename)
                    idx = 0
                    prev = None
                    with open(outfile, 'r') as o3:
                        for line in o3:
                            key, value = line.rstrip().split("\t", 2)
                            if prev != None and key != prev:
                                idx = idx + 1
                            prev = key
                            current_file = idx % reducers
                            tmp_file = reducer_files[current_file][0]
                            with open (tmp_file, 'a') as t_in:
                                t_in.write(line)
                    os.remove(outfile)
                    self.reducing(files = reducer_files)
        elif (data["message_type"] == "shutdown"):
            for w in self.worker_status: #dead workers?
                msg = {
                    "message_type": "shutdown"
                }
                message = json.dumps(msg)
                # Send the data to the port that master is on
                try:
                    sock = socket(AF_INET, SOCK_STREAM)
                    sock.connect(("localhost", self.port_list[w]))
                    sock.setblocking(0)
                    sock.sendall(str.encode(message))
                    sock.close()
                except error:
                    print("Failed to send shutdown to worker.")
            self.shutdown = True
            sys.exit(0)
    def master_heartbeat(self, port):
        sock = socket(AF_INET, SOCK_DGRAM)
        sock.bind(("localhost", port))

        while True:
            all_data, addr = sock.recvfrom(4096);
            msg = json.loads(all_data.decode("utf-8"))
            if (msg["message_type"] == "heartbeat"):
            	self.hb_record[msg["worker_pid"]] = time.time()
        sock.close()
    def fault_tolerance(self):
        while True:
            if self.shutdown == True:
                break
            ctime = time.time()
            #tmp_record = copy.deepcopy(self.hb_record)
            for i in list(self.hb_record):
                if self.worker_status[i] != "dead":

                    if (ctime - self.hb_record[i])>10:
                        print(i, "worker is dead.")
                        self.worker_status[i] = "dead"
                        if i in self.busy_list:
                            tmp_work = self.busy_list[i]
                            del self.busy_list[i]
                            for x in self.worker_status:
                                if (self.worker_status[x] == "busy" or self.worker_status[x] == "ready"):
                                    worker_id = x;
                                    break;
                            for works in tmp_work:
                                works["worker_pid"] = worker_id
                                if (worker_id not in self.busy_list):
                                    self.busy_list[worker_id] = []
                                    self.busy_list[worker_id].append(works)
                                else:
                                    self.busy_list[worker_id].append(works)
                                self.worker_status[worker_id] = "busy"
                                message = json.dumps(works)
                                try:
                                    sock = socket(AF_INET, SOCK_STREAM)
                                    sock.connect(("localhost", self.port_list[worker_id]))
                                    sock.setblocking(0)
                                    sock.sendall(str.encode(message))
                                    sock.close()
                                except error:
                                    print("dead phase: Failed to send job to worker.")

if __name__ == '__main__':

    p = Process(target=Master, args=(int(sys.argv[1]),))
    p.start()


	#Worker(6000,6001)

	#Worker(6000,6002)
