﻿# P4 Make MapReduce Great Again

## Contribution:
### Rui Zhou: Master: mapping, grouping, handle_msg Worker:handle_msg
### Feiyang Liu: Mater: init, heartbeat, tolerance, reducing Worker:init, heartbeat, handle——msg
ruizhou agreed upon contribution

fyliu agreed upon contribution
