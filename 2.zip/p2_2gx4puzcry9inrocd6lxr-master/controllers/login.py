from flask import *

from extensions import *

from config import *

import os, sys
import hashlib
import uuid
login = Blueprint('login', __name__, template_folder='templates')

# Page 404 haven't considered yet


@login.route('/3ec1buij/p2/login', methods=['GET', 'POST'])
def login_route():
	db = connect_to_database()
	cur = db.cursor()
	no_username = False
	field_username = False
	field_password = False
	wrong_password = False
	cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',0)' % ('enter login page'))
	if request.method == 'POST':
		username = request.form.get('username')
		password = request.form.get('password')
		cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',0)' % (username+' '+password))
		if username == '':
			field_username = True
		if password == '':
			field_password = True
		if (username != ''):
			rows_count = cur.execute('SELECT password FROM User WHERE username = \'%s\'' % (username))
			results = cur.fetchall()
			if rows_count == 0:
				no_username = True
			elif (password != ''):
				algorithm = 'sha512'
				salt = results[0]['password'].rsplit('$',2)
				salt = salt[1]
				m = hashlib.new(algorithm)
				m.update(str(salt + password).encode('utf-8'))
				password_hash = m.hexdigest()
				new_password = "$".join([algorithm,salt,password_hash])
				if new_password == results[0]['password']:
					cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',1)' % (username+' '+password))
					session['username'] = username
					return redirect("/3ec1buij/p2/")
				else:
					wrong_password = True

	options = {
		'host': config.env['host'],
		'port': config.env['port'],
		'no_username': no_username,
		'field_username': field_username,
		'field_password': field_password,
		'wrong_password': wrong_password
	}
	return render_template("login.html", **options)
