from flask import *

from extensions import *

from config import *

import hashlib, uuid

import re, os

user = Blueprint('user', __name__, template_folder='templates')
@user.route('/3ec1buij/p2/user', methods = ['GET','POST'])
def user_route():
	# If already login, redirect to user/edit;
	if 'username' in session:
		return redirect('/3ec1buij/p2/user/edit')
	# Link to database
	db = connect_to_database()
	cur = db.cursor()
	# Check if there are any mistake
	mistake = [0]*18;
	username = request.form.get('username')
	firstname = request.form.get('firstname')
	lastname = request.form.get('lastname')
	password1 = request.form.get('password1')
	password2 = request.form.get('password2')
	email = request.form.get('email')
	if request.method == 'POST':
		# No field (1 username, 2 firstname, 3 lastname, 4 password1, and 5 email) is allowed to be left blank. You do not need to check password2
		if len(username) == 0:
			mistake[0] = 1
			mistake[1] = 1
		if len(firstname) == 0:
			mistake[0] = 1
			mistake[2] = 1
		if len(lastname) == 0:
			mistake[0] = 1
			mistake[3] = 1
		if len(password1) == 0:
			mistake[0] = 1
			mistake[4] = 1
		if len(email) == 0:
			mistake[0] = 1
			mistake[5] = 1
		# Except for password and email, all fields(6 username, 7 firstname, and 8 lastname) have a max length of 20
		if len(username) > 20:
			mistake[0] = 1
			mistake[6] = 1
		if len(firstname) > 20:
			mistake[0] = 1
			mistake[7] = 1
		if len(lastname) > 20:
			mistake[0] = 1
			mistake[8] = 1
		# 9 The username must be unique (case insensitive)
		cur.execute('SELECT username FROM User')
		User = cur.fetchall()
		for Username in User:
			Username = Username['username']
			if username.lower() == Username.lower():
				mistake[0] = 1
				mistake[9] = 1
		# 10 The username must be at least three characters long
		if len(username) < 3:
			mistake[0] = 1
			mistake[10] = 1
		# 11 The username can only have letters, digits and underscores
		if not re.match('^[\w]*$', username):
			mistake[0] = 1
			mistake[11] = 1
		# 12 The password (check on password1, not password2) should be at least 8 characters long
		if len(password1) < 8:
			mistake[0]  = 1
			mistake[12] = 1
		# 13 The password (again, on password1) must contain at least one digit and at least one letter
		if not re.match('^(?=.*[a-zA-z])(?=.*\d)', password1):
			mistake[0] = 1
			mistake[13] = 1
		# 14 The password (again, on password1) can only have letters, digits and underscores
		if not re.match('^[\w]*$', password1):
			mistake[0] = 1
			mistake[14] = 1
		# 15 The first and second password inputs must match
		if password1 != password2:
			mistake[0] = 1
			mistake[15] = 1
		# 16 Email address should be syntactically valid (see below for more information)
		if not re.match('[^@]+@[^@]+\.[^@]+', email):
			mistake[0] = 1
			mistake[16] = 1
		# 17 The email has a max length of 40
		if len(email) > 40:
			mistake[0]  = 1
			mistake[17] = 1
		# If no mistake, add to database
		if mistake[0] == 0:
			algorithm = 'sha512'
			password = password1
			salt = uuid.uuid4().hex
			m = hashlib.new(algorithm)
			m.update(str(salt + password).encode('utf-8'))
			password_hash = m.hexdigest()
			tmp_password = str('$'.join([algorithm,salt,password_hash]))
			cur.execute('INSERT INTO User (username, firstname, lastname, password, email) VALUES (\'%s\', \'%s\', \'%s\', \'%s\', \'%s\')' %(username, firstname, lastname, tmp_password, email))
			return redirect("/3ec1buij/p2/login")
	options = {
		"edit": False,
		"mistake": mistake
	}
	return render_template('user.html', **options)
@user.route('/3ec1buij/p2/user/edit', methods = ['GET','POST'])
def edit_user():
	# If not login, redirect to login page;
	if 'username' not in session:
		return redirect('/3ec1buij/p2/login')
	# Link to database
	login = True
	db = connect_to_database()
	cur = db.cursor()
	username = session['username']
	# Check if there are any mistake
	mistake_edit = [0]*9;
	if request.method == 'POST':
		# Except for password and email, all fields(1 firstname, and 2 lastname) have a max length of 20
		if request.form.get('firstname'):
			firstname = request.form.get('firstname')
			if len(firstname) > 20:
				mistake_edit[0] = 1
				mistake_edit[1] = 1
			if mistake_edit[0] == 0:
				cur.execute('UPDATE User SET firstname = \'%s\' WHERE username = \'%s\'' %(firstname, username))
		if request.form.get('lastname'):
			lastname = request.form.get('lastname')
			if len(lastname) > 20:
				mistake_edit[0] = 1
				mistake_edit[2] = 1
			if mistake_edit[0] == 0:
				cur.execute('UPDATE User SET lastname = \'%s\' WHERE username = \'%s\'' %(lastname, username))
		if request.form.get('password1'):
			password1 = request.form.get('password1')
			password2 = request.form.get('password2')
			# 3 The password (check on password1, not password2) should be at least 8 characters long
			if len(password1) < 8:
				mistake_edit[0] = 1
				mistake_edit[3] = 1
			# 4 The password (again, on password1) must contain at least one digit and at least one letter
			if not re.match("^(?=.*[a-zA-z])(?=.*\d)", password1):
				mistake_edit[0] = 1
				mistake_edit[4] = 1
			# 5 The password (again, on password1) can only have letters, digits and underscores
			if not re.match("^[\w]*$", password1):
				mistake_edit[0] = 1
				mistake_edit[5] = 1
			# 6 The first and second password inputs must match
			if password1 != password2:
				mistake_edit[0] = 1
				mistake_edit[6] = 1
			if mistake_edit[0] == 0:
				algorithm = 'sha512'
				password = password1
				salt = uuid.uuid4().hex
				m = hashlib.new(algorithm)
				m.update(str(salt + password).encode('utf-8'))
				password_hash = m.hexdigest()
				tmp_password = str('$'.join([algorithm,salt,password_hash]))
				cur.execute('UPDATE User SET password = \'%s\' WHERE username = \'%s\'' %(tmp_password, username))
		if request.form.get('email'):
			email = request.form.get('email')
			# 7 Email address should be syntactically valid (see below for more information)
			if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
				mistake_edit[0] = 1
				mistake_edit[7] = 1
			# 8 The email has a max length of 40
			if len(email) > 40:
				mistake_edit[0] = 1
				mistake_edit[8] = 1
			if mistake_edit[0] == 0:
				cur.execute('UPDATE User SET email = \'%s\' WHERE username = \'%s\'' %(email, username))
	cur.execute('SELECT * FROM User WHERE username = \'%s\'' % username)
	personal_info = cur.fetchall()
	options = {
		"login": login,
		"edit": True,
		"mistake_edit": mistake_edit,
		"firstname": personal_info[0]['firstname'],
		"lastname": personal_info[0]['lastname']
	}
	return render_template('user.html', **options)
