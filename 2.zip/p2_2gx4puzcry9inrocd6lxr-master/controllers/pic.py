from flask import *
from extensions import *
from config import *

from extensions import *

from config import *

pic = Blueprint('pic', __name__, template_folder='templates')

@pic.route('/3ec1buij/p2/pic', methods=['GET', 'POST'])
def pic_route():
	picid = request.args.get('picid')
	db = connect_to_database()
	cur = db.cursor()
	login = False
	firstname = ''
	lastname = ''
	user = ''
	cur.execute("SELECT albumid FROM Contain WHERE picid = %s" , [picid])
	results = cur.fetchall()
	albumid = results[0]['albumid']
	if ('username' in session):
		login = True
		user = session['username']
		cur.execute('SELECT firstname, lastname FROM User WHERE username = \'%s\'' % (user))
		user_info = cur.fetchall()
		firstname = user_info[0]['firstname']
		lastname = user_info[0]['lastname']
	rows_count = cur.execute('SELECT title, albumid, username, access from Album where albumid = %s' % albumid)
	if rows_count == 0:
		abort(404)
	title = cur.fetchall()
	owner = False
	ownerName = title[0]['username']
	if user == title[0]['username']:
		owner = True
	if (title[0]['access'] == 'private') and (login == False):
		return redirect('/3ec1buij/p2/login')
	if (login == True) and (title[0]['access'] == 'private') and (owner == False):
		rows_count = cur.execute('SELECT username from AlbumAccess where albumid = %s and username = \'%s\'' % (albumid,user))
		if rows_count == 0:
		    abort(403)
	cur.execute("SELECT albumid FROM Contain WHERE picid = %s" , [picid])
	results = cur.fetchall()
	albumid = results[0]['albumid']
	row_count = cur.execute("SELECT format from Photo where picid = %s", [picid])
	if row_count == 0:
		abort(404)
	results = cur.fetchall()
	pic_format = results[0]['format']

	cur.execute("SELECT title from Album where albumid = %s", [albumid])
	results = cur.fetchall()
	title = results[0]['title']

	cur.execute("SELECT sequencenum from Contain where picid = %s", [picid])
	results = cur.fetchall()
	seq = results[0]['sequencenum']
	cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum", [albumid])
	results = cur.fetchall()
	minpicid = results[0]['picid']

	cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum DESC", [albumid])
	results = cur.fetchall()
	maxpicid = results[0]['picid']

	isprev = True
	isnext = True
	nextpicid = picid
	prevpicid = picid

	print(maxpicid)

	if picid == minpicid:
		isprev = False
	else:
		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum < %s order by sequencenum DESC", [albumid, seq])
		results = cur.fetchall()
		prevpicid = results[0]['picid']

	if picid == maxpicid:
		isnext = False
	else:
		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum > %s order by sequencenum", [albumid, seq])
		results = cur.fetchall()
		nextpicid = results[0]['picid']
	op = request.form.get('op')
	if request.method == 'POST':
		if op == 'caption':
			picid = request.form.get('picid')
			caption = request.form.get('caption')
			cur.execute("UPDATE Album SET lastupdated = CURRENT_TIMESTAMP where albumid = %s" %albumid)
			cur.execute("UPDATE Contain SET caption = \'%s\' where picid = \'%s\'" % (caption, picid))

	cur.execute("SELECT caption FROM Contain WHERE picid = %s" , [picid])
	results = cur.fetchall()
	caption = results[0]['caption']

	options = {

		'host': config.env['host'],
		'albumid': albumid,
		'picid': picid,
		'format':pic_format,
		'title':title,
		'port': config.env['port'],
		'isprev':isprev,
		'isnext':isnext,
		'prev':prevpicid,
		'next':nextpicid,
		'owner': owner,
		'caption': caption,
		'login':login,
		'ownerName': ownerName,
		'firstname': firstname,
		'lastname': lastname
	}
	return render_template("pic.html", **options)
