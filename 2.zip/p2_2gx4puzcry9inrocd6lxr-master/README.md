# EECS 485 Project 2 Authentication and Sessions

## Group 11

## Contributions:
### Feiyang Liu: SQL, User, User/edit, Albums
### Rui Zhou: Login, Logout, Album, Pic
ruizhou agreed upon contribution

fyliu agreed upon contribution
