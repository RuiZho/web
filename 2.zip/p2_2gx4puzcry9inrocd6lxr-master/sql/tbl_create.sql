DROP DATABASE IF EXISTS group11db;
CREATE DATABASE group11db;
USE group11db;
CREATE TABLE User(
	username	VARCHAR(20) PRIMARY KEY,
	firstname	VARCHAR(20),
	lastname	VARCHAR(20),
	password	VARCHAR(256),
	email		VARCHAR(40)
);
CREATE TABLE Album(
	albumid		INT PRIMARY KEY AUTO_INCREMENT,
	title		VARCHAR(50),
	created		TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	lastupdated	TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	username	VARCHAR(20),
	access ENUM('public','private') DEFAULT 'private',
	INDEX (username),
	FOREIGN KEY (username) REFERENCES User(username) ON DELETE CASCADE
);
CREATE TABLE Contain(
	sequencenum	INT PRIMARY KEY,
	albumid		INT,
	picid		VARCHAR(40),
	caption		VARCHAR(255),
	INDEX (picid, albumid),
	FOREIGN KEY (albumid) REFERENCES Album(albumid) ON DELETE CASCADE
);
CREATE TABLE Photo(
	picid		VARCHAR(40),
	format		CHAR(3),
	date		TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	INDEX (picid),
	FOREIGN KEY (picid) REFERENCES Contain(picid) ON DELETE CASCADE
);
CREATE TABLE AlbumAccess(
	albumid		INT,
	username	VARCHAR(20),
	PRIMARY KEY (albumid, username),
	FOREIGN KEY (albumid) REFERENCES Album(albumid) ON DELETE CASCADE,
	FOREIGN KEY (username) REFERENCES User(username)
);
CREATE TABLE try(
	action		VARCHAR(40),
	name		VARCHAR(40),
	status		INT
);
