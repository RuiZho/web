# EECS 485 Project 1 Interactive Photo Album

## Group 11

## Contributions:

### Feiyang Liu: Part 1. Part 2: Invalid Pages. Part 3. 

### Rui Zhou: Part 2: Home Page, Albums, Album Edit (delete). Part 3. 

### Yan Li: Part2: Album, Album Edit(add), Pic. Part 3.

ruizhou agreed upon contributions.

Feiyang Liu agreed upon contributions.

Yan Li agreed upon contributions.
