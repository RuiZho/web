import os
import hashlib
path = "C:/images"
file_name = os.listdir(path)
f = open('C:/work/tmp.sql','r+')
f.write('INSERT INTO Photo VALUES\n')
for i in file_name:
	if i[0:3] == 'spo':
		albumid = 1
	elif i[0:3] == 'foo':
		albumid = 2
	elif i[0:3] == 'wor':
		albumid = 3
	else:
		albumid = 4
	m = hashlib.md5((str(albumid)+i).encode('utf-8'))
	picid = str(m.hexdigest())
	f.write('\t(\'%s\',\t\'jpg\',\tDEFAULT),\n' %(picid))
	
f.write('INSERT INTO Contain (albumid, picid, caption) VALUES\n')
for i in file_name:
	if i[0:3] == 'spo':
		albumid = 1
	elif i[0:3] == 'foo':
		albumid = 2
	elif i[0:3] == 'wor':
		albumid = 3
	else:
		albumid = 4
	m = hashlib.md5((str(albumid)+i).encode('utf-8'))
	picid = str(m.hexdigest())
	f.write('\t(%d, \'%s\',\t\'\'),\n' %(albumid, picid))
f.close()