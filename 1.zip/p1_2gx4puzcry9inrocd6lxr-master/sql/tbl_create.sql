DROP DATABASE IF EXISTS group11db;
CREATE DATABASE group11db;
USE group11db;
CREATE TABLE User(
	username	VARCHAR(20) PRIMARY KEY,
	firstname	VARCHAR(20),
	lastname	VARCHAR(20),
	password	VARCHAR(20),
	email		VARCHAR(40)
);
CREATE TABLE Album(
	albumid		INT PRIMARY KEY AUTO_INCREMENT,
	title		VARCHAR(50),
	created		TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	lastupdated	TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	username	VARCHAR(20),
	INDEX (username),
	FOREIGN KEY (username) REFERENCES User(username) ON DELETE CASCADE
);
CREATE TABLE Contain(
	sequencenum	INT PRIMARY KEY,
	albumid		INT,
	picid		VARCHAR(40),
	caption		VARCHAR(255),
	INDEX (picid, albumid),
	FOREIGN KEY (albumid) REFERENCES Album(albumid) ON DELETE CASCADE
);
CREATE TABLE Photo(
	picid		VARCHAR(40),
	format		CHAR(3),
	date		TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	INDEX (picid),
	FOREIGN KEY (picid) REFERENCES Contain(picid) ON DELETE CASCADE
);
CREATE TABLE try(
	photoname	VARCHAR(40),
	photoid		VARCHAR(40),
	album		INT
);
