from flask import *

from extensions import *

from config import *

import hashlib

import os,sys

album = Blueprint('album', __name__, template_folder='templates')
@album.route('/3ec1buij/p1/album')
def album_route():
	albumid = str(request.args.get('albumid'))
	if albumid == None or albumid.isdigit() == 0:
		abort(404)
	db = connect_to_database()
	cur = db.cursor()
	rows_count = cur.execute('SELECT title, albumid from Album where albumid = %s' % albumid)
	if rows_count == 0:
		abort(404)
	title = cur.fetchall()
	cur.execute('SELECT P.picid, P.format, A.albumid, A.lastupdated FROM Album A, Photo P, Contain C WHERE A.albumid = %s and A.albumid = C.albumid and C.picid = P.picid' % albumid)
	photos = cur.fetchall()
	options = {
	    'title' : title[0]['title'],
		'host': config.env['host'],
		'albumid': albumid,
		"edit": False,
		'port': config.env['port'],
		'photos': photos
	}
	return render_template("album.html", **options)

@album.route('/3ec1buij/p1/album/edit', methods=['GET', 'POST'])
def album_edit_route():
	ALLOWED_EXTENSIONS = set(['png', 'jpg', 'bmp', 'gif'])
	albumid = str(request.args.get('albumid'))
	if albumid == None or albumid.isdigit() == 0:
		abort(404)
	op = request.form.get('op')
	db = connect_to_database()
	cur = db.cursor()
	cur.execute("SELECT sequencenum FROM Contain order by sequencenum DESC")
	max_seq = cur.fetchall()
	seq = max_seq[0]['sequencenum']
	if request.method == 'POST':
		if op == "add":
			albumid = request.form.get('albumid')
			fileupload = request.files.get('file') #file storage
			fullname = fileupload.filename  #filename
			file_name, file_extension = os.path.splitext(fullname)
			image_format = file_extension[1:]
			m = hashlib.md5((str(albumid) + str(fullname)).encode('utf-8'))
			picid = str(m.hexdigest())
			cur.execute("INSERT INTO try (album, photoname, photoid) VALUES (%s, \'%s\', \'%s\')" % (albumid, fullname, picid))
			if image_format.lower() in ALLOWED_EXTENSIONS:
				cur.execute("INSERT INTO try (album, photoname, photoid) VALUES (%s, \'%s\', \'%s\')" % (albumid+'100', fullname, picid))
				cur.execute("INSERT INTO Contain (sequencenum, albumid, picid) VALUES (%s, %s, \'%s\')" % (seq + 1, albumid, picid))
				cur.execute("INSERT INTO Photo (picid, format) VALUES (\'%s\', \'%s\')" % (picid, image_format))
				cur.execute("UPDATE Album SET lastupdated = CURRENT_TIMESTAMP where albumid = %s" %albumid)
				fileupload.save(os.path.join('static/images/', picid + file_extension))
		if op == "delete":
			picid = request.form.get('picid')
			albumid = request.form.get('albumid')
			cur.execute("SELECT format FROM Photo WHERE picid = \'%s\'" % picid)
			format_f = cur.fetchall()
			cur.execute("DELETE FROM Contain WHERE picid = \'%s\'" % picid)
			cur.execute("UPDATE Album SET lastupdated = CURRENT_TIMESTAMP where albumid = %s" %albumid)
			os.remove(os.path.join('static/images/', picid + "." + str(format_f[0]['format'])))
	rows_count = cur.execute("SELECT title, albumid FROM Album where albumid = %s" % albumid)
	if rows_count > 0:
		title = cur.fetchall()
	else:
		abort(404)
	cur.execute('SELECT P.picid, P.format, A.albumid, A.lastupdated FROM Album A, Photo P, Contain C WHERE A.albumid = %s and A.albumid = C.albumid and C.picid = P.picid' % albumid)
	photos = cur.fetchall()
	options = {
		"albumid": albumid,
		"title": title[0]['title'],
		"host": config.env['host'],
		"port": config.env['port'],
		"edit": True,
		"photos": photos
	}
	return render_template("album.html", **options)
