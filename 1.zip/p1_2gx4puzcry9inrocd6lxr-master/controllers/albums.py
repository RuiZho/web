from flask import *

from extensions import *

from config import *

import os, sys

albums = Blueprint('albums', __name__, template_folder='templates')


# Page 404 haven't considered yet

@albums.route('/3ec1buij/p1/albums')
def albums_route():
	user = request.args.get('username')
	db = connect_to_database()
	cur = db.cursor()
	rows_count = cur.execute('SELECT password FROM User WHERE username = \'%s\'' % (user))
	if rows_count == 0:
		abort(404)
	cur.execute('SELECT albumid, title, username FROM Album WHERE username = \'%s\'' % (user))
	results = cur.fetchall()
	options = {

		'host': config.env['host'],
		'user': user,
		"edit": False,
		'port': config.env['port'],
		'results': results
	}
	return render_template("albums.html", **options)



@albums.route('/3ec1buij/p1/albums/edit', methods=['GET', 'POST'])
def albums_edit_route():
	user = request.args.get('username')
	op = request.form.get('op')
	db = connect_to_database()
	cur = db.cursor()


	if request.method == 'POST':
		if op == "add":
			username = request.form.get('username')
			title = request.form.get('title')
			cur.execute("INSERT INTO try (album, photoname, photoid) VALUES (%s, \'%s\', \'%s\')" % ('100', 'create album', 'title'))
			cur.execute('INSERT INTO Album (title, username, created, lastupdated) VALUES (\'%s\', \'%s\', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)' % (title, user))
		elif op == "delete":
			albumid = request.form.get('albumid')
			cur.execute("INSERT INTO try (album, photoname, photoid) VALUES (%s, \'%s\', \'%s\')" % (albumid, 'delete album', ' '))
			cur.execute('SELECT picid FROM Contain WHERE albumid = %s' % albumid)
			pic = cur.fetchall()
			for pic_id in pic:
				cur.execute("INSERT INTO try (album, photoname, photoid) VALUES (%s, \'%s\', \'%s\')" % (albumid, 'delete album pic', str(pic_id['picid'])))
				cur.execute('SELECT format FROM Photo WHERE picid = \'%s\'' % (str(pic_id['picid'])))
				format_f = cur.fetchall()
				os.remove(os.path.join('static/images/', str(pic_id['picid']) + "." + str(format_f[0]['format'])))
			cur.execute('DELETE FROM Album WHERE albumid = %s' % albumid)
	rows_count = cur.execute('SELECT password FROM User WHERE username = \'%s\'' % (user))
	if rows_count == 0:
		abort(404)
	cur.execute('SELECT albumid, title, username FROM Album WHERE username = \'%s\'' % (user))
	results = cur.fetchall()
	options = {
		'host': config.env['host'],
		'user': user,
		"edit": True,
		'port': config.env['port'],
		'results': results
	}
	return render_template("albums.html", **options)
