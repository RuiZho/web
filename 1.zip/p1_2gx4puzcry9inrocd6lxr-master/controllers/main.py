from flask import *

from extensions import *

from config import *

main = Blueprint('main', __name__, template_folder='templates')

@main.route('/3ec1buij/p1/')
def main_route():
    db = connect_to_database()
    cur = db.cursor()
    cur.execute('SELECT username FROM User')
    results = cur.fetchall()
    options = {
      'host': config.env['host'],
      'port': config.env['port'],
      'results': results
    }
    return render_template("base.html", **options)
