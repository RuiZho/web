from flask import *
from extensions import *
from config import *

from extensions import *

from config import *

pic = Blueprint('pic', __name__, template_folder='templates')

@pic.route('/3ec1buij/p1/pic')
def pic_route():
	picid = request.args.get('picid')
	db = connect_to_database()
	cur = db.cursor()

	row_count = cur.execute("SELECT format from Photo where picid = %s", [picid])
	if row_count == 0:
		abort(404)
	results = cur.fetchall()
	pic_format = results[0]['format']

	cur.execute("SELECT albumid FROM Contain WHERE picid = %s" , [picid])
	results = cur.fetchall()
	albumid = results[0]['albumid']

	cur.execute("SELECT title from Album where albumid = %s", [albumid])
	results = cur.fetchall()
	title = results[0]['title']

	cur.execute("SELECT sequencenum from Contain where picid = %s", [picid])
	results = cur.fetchall()
	seq = results[0]['sequencenum']
	cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum", [albumid])
	results = cur.fetchall()
	minpicid = results[0]['picid']

	cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum DESC", [albumid])
	results = cur.fetchall()
	maxpicid = results[0]['picid']

	isprev = True
	isnext = True
	nextpicid = picid
	prevpicid = picid

	print(maxpicid)

	if picid == minpicid:
		isprev = False
	else:
		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum < %s order by sequencenum DESC", [albumid, seq])
		results = cur.fetchall()
		prevpicid = results[0]['picid']

	if picid == maxpicid:
		isnext = False
	else:
		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum > %s order by sequencenum", [albumid, seq])
		results = cur.fetchall()
		nextpicid = results[0]['picid']

	options = {

		'host': config.env['host'],
		'albumid': albumid,
		'picid': picid,
		'format':pic_format,
		'title':title,
		'port': config.env['port'],
		'isprev':isprev,
		'isnext':isnext,
		'prev':prevpicid,
		'next':nextpicid
	}
	return render_template("pic.html", **options)
