# Do NOT commit this file to github
# Make a seperate one for your deployed environment
# Do not change the host, it is referring to database host not website host
env = dict(
	host = '0.0.0.0',
	port = 3000,
	user = 'root',
	password = 'root',
	db = 'db',
)
