# IR-project-Travel-Pal

## Useful Dataset
### Trip advisor dataset: http://times.cs.uiuc.edu/~wang296/Data/
### City info dataset: They are related to the following locations: Amsterdam, Tuscany, Barcelona, Berlin, Dubai, London, Paris and Rome. http://tour-pedia.org/about/datasets.html
### Kaggle dataset: https://www.kaggle.com/datasets?sortBy=hottest&group=featured
### museum dataset: https://www.kaggle.com/imls/museum-directory

