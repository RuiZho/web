from flask import *

from extensions import *

from config import *

import hashlib

import os,sys
import re
import shutil
import math
import json, requests

wikiserver = Blueprint('wikiserver', __name__, template_folder='templates')


@wikiserver.route('/3ec1buij/p5/wikipedia', methods=['GET', 'POST'])
def wikisever_route():
	#request method = get?
	w = request.args.get('w')
	q = request.args.get('q')
	db = connect_to_database()

	search = False
	summary = False
	no_result = False
	results = list()
	list1 = list()
	if w is not None and q is not None:
		q = q.replace("_", " ")
		search = True
		host = config.env['host']
		serverport = config.env['port'] - 1
		port = config.env['port']

		resp = requests.get('http://'+ str(host)+':'+ str(serverport) +'/3ec1buij/p5'+ '/?q='+str(q)+"&w=" +str(w))
		data = json.loads(resp.text)
		list1 = data['hits']
		count = 0

		if len(list1) == 0:
			no_result = True
		else:
			for x in list1:
				if count >= 10:
					break
				else:
					cur = db.cursor()
					cur.execute("SELECT docid, title, categories, image, summary FROM "+"Documents WHERE docid = \'%s\'" %(x['docid']))
					count = count + 1
					tmp = cur.fetchall()
					results.append(tmp[0])
	options = {
		'host': config.env['host'],
		'port': config.env['port'],
		'results': results,
		'search': search,
		'summary': summary,
		'no_result': no_result
	}
	return render_template("base.html", **options)



#/3ec1buij/p5/wikipedia/summary
@wikiserver.route('/3ec1buij/p5/wikipedia/summary', methods=['GET', 'POST'])
def wikiserver_summary_route():
	docid = request.args.get('id')
	db = connect_to_database()
	search = True
	summary = True
	no_result = False
	cur = db.cursor()
	cur.execute("SELECT docid, title, categories, image, summary FROM "+"Documents WHERE docid = \'%s\'" % docid)
	tmp = cur.fetchall()
	q = tmp[0]['title']
	q = q.replace("_", " ")
	host = config.env['host']
	serverport = config.env['port'] - 1
	w = 0.15
	resp = requests.get('http://'+ str(host)+':'+ str(serverport) +'/3ec1buij/p5'+ '/?q='+str(q)+"&w=" +str(w))
	data = json.loads(resp.text)
	list1 = data['hits']
	count = 0
	simidocs = list()
	for x in list1:
		if count >= 10:
			break
		else:
			if x['docid'] != docid:
				cur = db.cursor()
				cur.execute("SELECT docid, title, categories, image, summary FROM "+"Documents WHERE docid = \'%s\'" %(x['docid']))
				count = count + 1
				tmp1 = cur.fetchall()
				simidocs.append(tmp1[0])
	options = {
		'host': config.env['host'],
		'port': config.env['port'],
		'simidocs': simidocs,
		'search': search,
		'summary': summary,
		'no_result': no_result,
		'docid': tmp[0]['docid'],
		'title': tmp[0]['title'],
		'docsummary': tmp[0]['summary'],
		'categories': tmp[0]['categories'],
		'image': tmp[0]['image']
	}
	return render_template("base.html", **options)
