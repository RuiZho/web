# Do NOT commit this file to github
# Make a seperate one for your deployed environment
# Do not change the host, it is referring to database host not website host
env = dict(
	host = '0.0.0.0',
	port = 4251,
	user = 'group11',
	password = 'group11pw!',
	db = 'group11db',
)
