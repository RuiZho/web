from flask import *

from extensions import *

from config import *

import hashlib

import os,sys
import re
import shutil
import math



stoplist = list()
pagerank = dict()
idf = dict()
wordlist = dict()
print("fetch info test")
with open('stopwords.txt', 'r') as s:
    for line in s:
        tmp = line.strip()
        q = (re.sub(r'[^a-zA-Z0-9]+', '', tmp)).lower()
        stoplist.append(q)

with open('pagerank.out', 'r') as s:
	for word in s:
		tmp = [x.strip() for x in word.split(',')]
		pagerank[tmp[0]] = tmp[1]

with open('outfile.txt', 'r') as s:
	for word in s:
		tmp = word.split()
		idf[tmp[0]]	= tmp[1]
		l = len(tmp) - 2
		wordlist[tmp[0]] = dict()
		for i in range(0,l):
			if i%3 == 0:
				wordlist[tmp[0]][tmp[i+2]]=[tmp[i+3], tmp[i+4]]

server = Blueprint('server', __name__, template_folder='templates')
@server.route('/3ec1buij/p5/', methods=['GET', 'POST'])
def sever_route():
	w = request.args.get('w')
	q = request.args.get('q')
	q = (re.sub(r'[^a-zA-Z0-9 ]+', '', q)).lower()
	tmplist = q.split()
	qlist = dict()
	# use dict to store query frequency
	for x in tmplist:
		if x not in stoplist:
			if x in qlist:
				qlist[x] = qlist[x] + 1
			else:
				qlist[x] = 1

	# store doc in the doclist
	doclist = list()
	count=0
	for qword in qlist:
		if qword in wordlist:
			if count == 0:
				count = count + 1
				doclist = wordlist[qword]
			else:
				count = count + 1
				tmplist = wordlist[qword]
				doclist = list(set(doclist)&set(tmplist))
		else:
			doclist = list()
			break
	print("test!!!!", len(doclist))
	hits = list()
	for doc in doclist:
		top = 0.0
		normq = 0.0
		normd = 0.0
		if doc in pagerank:
			pscore = float(pagerank[doc])
		else:
			pscore = 0.0
		for qword in qlist:
			if qword in wordlist and doc in wordlist[qword]:
				normd = float(wordlist[qword][doc][1])
				qtf = float(qlist[qword])
				qidf = float(idf[qword])
				dtf = float(wordlist[qword][doc][0])
				normq = normq + math.pow(qidf*qtf,2)
				top = top + qtf*dtf*math.pow(qidf,2)
		cos = float(top)/math.sqrt(normd*normq)
		w1 = float(w)
		s = w1*pscore+(1-w1)*cos
		list1 = dict()
		list1['docid'] = doc
		list1['score'] = s
		hits.append(list1)
	hits.sort(key=lambda x: (x['docid']))
	hits.sort(key=lambda x: (x['score']), reverse=True)
	data = {'hits': hits}
	data1 = jsonify(data)
	return data1
