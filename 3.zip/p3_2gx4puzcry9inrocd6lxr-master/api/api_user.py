from flask import *

from extensions import *

from config import *

import hashlib, uuid

import re, os

api_user = Blueprint('api_user', __name__, template_folder='templates')
@api_user.route('/3ec1buij/p3/api/v1/user', methods = ['GET','POST','PUT'])
def user_route():
	print("Enter page")
	# Link to database
	db = connect_to_database()
	cur = db.cursor()
	# Code for GET:
	if request.method == 'GET':
		# Have session, return user information
		if 'username' in session:
			username = session['username']
			cur.execute('SELECT * FROM User WHERE username = \'%s\'' % username)
			query = cur.fetchall()
			return jsonify(username = username,firstname = query[0]['firstname'], lastname = query[0]['lastname'], email = query[0]['email'])
		# No session, return error information
		else:
			return jsonify(errors = [{"message": "You do not have the necessary credentials for the resource"}]), 401
	# Code for POST:
	if request.method == 'POST':
		print("POST")
		user_info = request.get_json() #http://stackoverflow.com/questions/23326368/flask-request-args-vs-request-form
		# Check if json has all needed information
		if 'username' not in user_info or 'firstname' not in user_info or 'lastname' not in user_info or 'password1' not in user_info or 'password2' not in user_info or 'email' not in user_info:
			return jsonify(errors = [{"message": "You did not provide the necessary fields"}]), 422
		else:
			username = user_info['username']
			firstname = user_info['firstname']
			lastname = user_info['lastname']
			password1 = user_info['password1']
			password2 = user_info['password2']
			email = user_info['email']
			# Check if there are any mistake
			mistake = [0, []]
			# Except for password and email, all fields(1 username, 2 firstname, and 3 lastname) have a max length of 20
			if len(username) > 20:
				mistake[0] = 1
				mistake[1].append({"message": "Username must be no longer than 20 characters"})
			if len(firstname) > 20:
				mistake[0] = 1
				mistake[1].append({"message": "Firstname must be no longer than 20 characters"})
			if len(lastname) > 20:
				mistake[0] = 1
				mistake[1].append({"message": "Lastname must be no longer than 20 characters"})
			# 4 The username must be unique (case insensitive)
			cur.execute('SELECT username FROM User')
			User = cur.fetchall()
			for Username in User:
				Username = Username['username']
				if username.lower() == Username.lower():
					mistake[0] = 1
					mistake[1].append({"message": "This username is taken"})
			# 5 The username must be at least three characters long
			if len(username) < 3:
				mistake[0] = 1
				mistake[1].append({"message": "Usernames must be at least 3 characters long"})
			# 6 The username can only have letters, digits and underscores
			if not re.match('^[\w]*$', username):
				mistake[0] = 1
				mistake[1].append({"message": "Usernames may only contain letters, digits, and underscores"})
			# 7 The password (check on password1, not password2) should be at least 8 characters long
			if len(password1) < 8:
				mistake[0]  = 1
				mistake[1].append({"message": "Passwords must be at least 8 characters long"})
			# 8 The password (again, on password1) must contain at least one digit and at least one letter
			if not re.match('^(?=.*[a-zA-z])(?=.*\d)', password1):
				mistake[0] = 1
				mistake[1].append({"message": "Passwords must contain at least one letter and one number"})
			# 9 The password (again, on password1) can only have letters, digits and underscores
			if not re.match('^[\w]*$', password1):
				mistake[0] = 1
				mistake[1].append({"message": "Passwords may only contain letters, digits, and underscores"})
			# 10 The first and second password inputs must match
			if password1 != password2:
				mistake[0] = 1
				mistake[1].append({"message": "Passwords do not match"})
			# 11 Email address should be syntactically valid (see below for more information)
			if not re.match('[^@]+@[^@]+\.[^@]+', email):
				mistake[0] = 1
				mistake[1].append({"message": "Email address must be valid"})
			# 12 The email has a max length of 40
			if len(email) > 40:
				mistake[0]  = 1
				mistake[1].append({"message": "Email must be no longer than 40 characters"})
			# If no mistake, add to database
			if mistake[0] == 0:
				algorithm = 'sha512'
				password = password1
				salt = uuid.uuid4().hex
				m = hashlib.new(algorithm)
				m.update(str(salt + password).encode('utf-8'))
				password_hash = m.hexdigest()
				tmp_password = str('$'.join([algorithm,salt,password_hash]))
				cur.execute('INSERT INTO User (username, firstname, lastname, password, email) VALUES (\'%s\', \'%s\', \'%s\', \'%s\', \'%s\')' %(username, firstname, lastname, tmp_password, email))
				return jsonify(username = username,firstname = firstname, lastname = lastname, password1 = password1, password2 = password2, email = email), 201
			# If there are mistakes, report the mistakes
			else:
				return jsonify(errors = mistake[1]), 422
	# Code for PUT:
	if request.method == 'PUT':
		user_info = request.get_json() #http://stackoverflow.com/questions/23326368/flask-request-args-vs-request-form
		# Check if json has all needed information
		if 'firstname' not in user_info or 'lastname' not in user_info or 'password1' not in user_info or 'password2' not in user_info or 'email' not in user_info:
			return jsonify(errors = [{"message": "You did not provide the necessary fields"}]), 422
		# No session, return error information
		elif 'username' not in session:
			return jsonify(errors = [{"message": "You do not have the necessary credentials for the resource"}]), 401
		# Have session, continue to work
		else:
			username = session['username']
			firstname = user_info['firstname']
			lastname = user_info['lastname']
			password1 = user_info['password1']
			password2 = user_info['password2']
			email = user_info['email']
			# Check if there are any mistake
			mistake_edit = [0, []]
			# Except for password and email, all fields(1 firstname, and 2 lastname) have a max length of 20
			if len(firstname) > 20:
				mistake_edit[0] = 1
				mistake_edit[1].append({"message": "Firstname must be no longer than 20 characters"})
			if len(lastname) > 20:
				mistake_edit[0] = 1
				mistake_edit[1].append({"message": "Lastname must be no longer than 20 characters"})
			if user_info['password1']:
				# 3 The password (check on password1, not password2) should be at least 8 characters long
				if len(password1) < 8:
					mistake_edit[0] = 1
					mistake_edit[1].append({"message": "Passwords must be at least 8 characters long"})
				# 4 The password (again, on password1) must contain at least one digit and at least one letter
				if not re.match("^(?=.*[a-zA-z])(?=.*\d)", password1):
					mistake_edit[0] = 1
					mistake_edit[1].append({"message": "Passwords must contain at least one letter and one number"})
				# 5 The password (again, on password1) can only have letters, digits and underscores
				if not re.match("^[\w]*$", password1):
					mistake_edit[0] = 1
					mistake_edit[1].append({"message": "Passwords may only contain letters, digits, and underscores"})
				# 6 The first and second password inputs must match
				if password1 != password2:
					mistake_edit[0] = 1
					mistake_edit[1].append({"message": "Passwords do not match"})
			# 7 Email address should be syntactically valid (see below for more information)
			if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
				mistake_edit[0] = 1
				mistake_edit[1].append({"message": "Email address must be valid"})
			# 8 The email has a max length of 40
			if len(email) > 40:
				mistake_edit[0] = 1
				mistake_edit[1].append({"message": "Email must be no longer than 40 characters"})
			if mistake_edit[0] == 0:
				print('update user information successfully')
				cur.execute('UPDATE User SET firstname = \'%s\' WHERE username = \'%s\'' %(firstname, username))
				session['firstname'] = firstname
				cur.execute('UPDATE User SET lastname = \'%s\' WHERE username = \'%s\'' %(lastname, username))
				session['lastname'] = lastname
				session['email'] = email
				cur.execute('UPDATE User SET email = \'%s\' WHERE username = \'%s\'' %(email, username))
				if user_info['password1']:
					algorithm = 'sha512'
					password = password1
					salt = uuid.uuid4().hex
					m = hashlib.new(algorithm)
					m.update(str(salt + password).encode('utf-8'))
					password_hash = m.hexdigest()
					tmp_password = str('$'.join([algorithm,salt,password_hash]))
					cur.execute('UPDATE User SET password = \'%s\' WHERE username = \'%s\'' %(tmp_password, username))
				return jsonify(username = username), 201
			else:
				return jsonify(errors = mistake_edit[1]), 422