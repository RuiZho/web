from flask import *
from extensions import *
from config import *

from extensions import *

from config import *

api_pic = Blueprint('api_pic', __name__, template_folder='templates')

@api_pic.route('/3ec1buij/p3/api/v1/pic/<picid>', methods=['GET', 'PUT'])
def api_pic_route(picid):
	db = connect_to_database()
	cur = db.cursor()
	login = False
	user = ''
	host = config.env['host']
	port = config.env['port']
	err = []
	if ('username' in session):
		login = True
		user = session['username']

	if request.method == 'GET':
		if not picid:
			err.append({"message": "The requested resource could not be found"})
			return jsonify(errors = err),404
		rows_count =cur.execute("SELECT albumid FROM Contain WHERE picid = %s" , [picid])
		if rows_count == 0:
			err.append({"message": "The requested resource could not be found"})
			return jsonify(errors = err),404
		results = cur.fetchall()
		albumid = results[0]['albumid']
		rows_count = cur.execute('SELECT title, albumid, username, access from Album where albumid = %s' % albumid)
		if rows_count == 0:
			err.append({"message": "The requested resource could not be found"})
			return jsonify(errors = err),404
		title = cur.fetchall()
		owner = False
		ownerName = title[0]['username']
		if user == title[0]['username']:
			owner = True
		if (title[0]['access'] == 'private') and (login == False):
			err.append({"message": "You do not have the necessary credentials for the resource"})
			return jsonify(errors=err),401
		if (login == True) and (title[0]['access'] == 'private') and (owner == False):
			rows_count = cur.execute('SELECT username from AlbumAccess where albumid = %s and username = \'%s\'' % (albumid,user))
			if rows_count == 0:
				err.append({"message": "You do not have the necessary permissions for the resource"})
				return jsonify(errors=err),403

		cur.execute("SELECT format from Photo where picid = %s", [picid])
		results = cur.fetchall()
		pic_format = results[0]['format']

		cur.execute("SELECT title from Album where albumid = %s", [albumid])
		results = cur.fetchall()
		title = results[0]['title']

		cur.execute("SELECT sequencenum from Contain where picid = %s", [picid])
		results = cur.fetchall()
		seq = results[0]['sequencenum']
		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum", [albumid])
		results = cur.fetchall()
		minpicid = results[0]['picid']

		cur.execute("SELECT sequencenum, picid from Contain where albumid = %s order by sequencenum DESC", [albumid])
		results = cur.fetchall()
		maxpicid = results[0]['picid']

		isprev = True
		isnext = True
		nextpicid = picid
		prevpicid = picid

		print(maxpicid)

		if picid == minpicid:
			prevpicid = 0
		else:
			cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum < %s order by sequencenum DESC", [albumid, seq])
			results = cur.fetchall()
			prevpicid = results[0]['picid']

		if picid == maxpicid:
			nextpicid = 0
		else:
			cur.execute("SELECT sequencenum, picid from Contain where albumid = %s and sequencenum > %s order by sequencenum", [albumid, seq])
			results = cur.fetchall()
			nextpicid = results[0]['picid']

		cur.execute("SELECT caption FROM Contain WHERE picid = %s" , [picid])
		results = cur.fetchall()
		caption = results[0]['caption']

		data = {
			'albumid': albumid,
			'caption': caption,
			'format':pic_format,
			'next':nextpicid,
			'picid': picid,
			'prev':prevpicid
		}
		return jsonify(data)
	if request.method == 'PUT':
		print("reach here")
		if (login == False):
			err.append({"message": "You do not have the necessary credentials for the resource"})
			return jsonify(errors=err),401
		arr = request.get_json()
		if "albumid" not in arr or "caption" not in arr or "picid" not in arr:
			#cannot access insert try here
			err.append({"message": "You did not provide the necessary fields"})
			return jsonify(errors=err),422
		put_albumid = arr["albumid"]
		put_caption = arr["caption"]
		put_picid = arr["picid"]
		rows_count =cur.execute("SELECT albumid FROM Contain WHERE picid = %s" , [put_picid])
		if rows_count == 0:
			err.append({"message": "The requested resource could not be found"})
			return jsonify(errors = err),404
		results = cur.fetchall()
		real_albumid = results[0]['albumid']
		if real_albumid != put_albumid:
			err.append({"message": "Picture is not part of this album!”"})
			return jsonify(errors = err),422
		rows_count = cur.execute('SELECT title, albumid, username, access from Album where albumid = %s' % put_albumid)
		if rows_count == 0:
			err.append({"message": "The requested resource could not be found"})
			return jsonify(errors = err),404
		title = cur.fetchall()
		owner = False
		ownerName = title[0]['username']
		if user == title[0]['username']:
			owner = True
		if owner == False:
			err.append({"message": "You do not have the necessary permissions for the resource"})
			return jsonify(errors=err),403
		cur.execute("UPDATE Album SET lastupdated = CURRENT_TIMESTAMP where albumid = %s" %put_albumid)
		cur.execute("UPDATE Contain SET caption = \'%s\' where picid = \'%s\'" % (put_caption, put_picid))
		return jsonify(arr),200
