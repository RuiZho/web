from flask import *

from extensions import *

from config import *

import os, sys
import hashlib
import uuid
api_login = Blueprint('api_login', __name__, template_folder='templates')

# Page 404 haven't considered yet


@api_login.route('/3ec1buij/p3/api/v1/login', methods=['POST'])
def api_login_route():

	db = connect_to_database()
	#arr = request.get_json()
	arr = request.get_json()
	username = arr['username']
	password = arr['password']
	err = []
	# not? null ? empty string?
	'''
	if username == '':
		err.append({"message": "test for null"}) #successful
		return jsonify(errors=err),422
	'''
	if "username" not in arr or "password" not in arr:
		#cannot access insert try here
		err.append({"message": "You did not provide the necessary fields"})
		return jsonify(errors=err),422
	cur = db.cursor()
	cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',0)' % ('enter login page'))
	cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',0)' % (username+' '+password))
	host = config.env['host']
	port = config.env['port']
	rows_count = cur.execute('SELECT password, firstname, lastname, email FROM User WHERE username = \'%s\'' % (username))
	results = cur.fetchall()
	if rows_count == 0:
		err.append({"message": "Username does not exist"})
		return jsonify(errors = err),404
	else:
		algorithm = 'sha512'
		salt = results[0]['password'].rsplit('$',2)
		salt = salt[1]
		m = hashlib.new(algorithm)
		m.update(str(salt + password).encode('utf-8'))
		password_hash = m.hexdigest()
		new_password = "$".join([algorithm,salt,password_hash])
		if new_password == results[0]['password']:
			cur.execute('INSERT INTO try VALUES(\'login\',\'%s\',1)' % (username+' '+password))
			session['username'] = username
			session['firstname'] = results[0]['firstname']
			session['lastname'] = results[0]['lastname']
			session['email'] = results[0]['email']
			return jsonify(username = username),200
		else:
			err.append({"message": "Password is incorrect for the specified username"})
			return jsonify(errors=err),422
