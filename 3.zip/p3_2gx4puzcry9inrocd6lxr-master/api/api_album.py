from flask import *

from extensions import *

from config import *

import hashlib

import os,sys

api_album = Blueprint('api_album', __name__, template_folder='templates')
@api_album.route('/3ec1buij/p3/api/v1/album/<albumid>', methods=['GET'])
def api_album_route(albumid):
	db = connect_to_database()
	cur = db.cursor()
	login = False
	user = ''
	err = []
	host = config.env['host']
	port = config.env['port']
	if ('username' in session):
		login = True
		user = session['username']
		#cur.execute('SELECT title, albumid, username from Album where albumid = %s' % albumid)
	rows_count = cur.execute('SELECT title, albumid, username, access, created, lastupdated from Album where albumid = %s' % albumid)
	if rows_count == 0:
		err.append({"message": "The requested resource could not be found"})
		return jsonify(errors=err),404
	title = cur.fetchall()
	owner = False
	ownerName = title[0]['username']
	if user == title[0]['username']:
		owner = True
	if (title[0]['access'] == 'private') and (login == False):
		#redirect?return redirect('/3ec1buij/p3/login')
		err.append({"message": "You do not have the necessary credentials for the resource"})
		return jsonify(errors=err),401
	if (login == True) and (title[0]['access'] == 'private') and (owner == False):
		rows_count = cur.execute('SELECT username from AlbumAccess where albumid = %s and username = \'%s\'' % (albumid,user))
		if rows_count == 0:
			err.append({"message": "You do not have the necessary permissions for the resource"})
			return jsonify(errors=err),403
	cur.execute('SELECT A.albumid, C.caption, P.date, P.format, P.picid, C.sequencenum FROM Album A, Photo P, Contain C WHERE A.albumid = %s and A.albumid = C.albumid and C.picid = P.picid' % albumid)
	pics = cur.fetchall()
	return jsonify({
	'access' : title[0]['access'],
	'albumid' : title[0]['albumid'],
	'created' : title[0]['created'],
	'lastupdated' : title[0]['lastupdated'],
	'pics' : pics,
	'title' : title[0]['title'],
	'username' : title[0]['username']
	})
