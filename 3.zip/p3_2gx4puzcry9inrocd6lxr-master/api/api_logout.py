from flask import *

from extensions import *

from config import *

import os, sys

api_logout = Blueprint('api_logout', __name__, template_folder='templates')

# Page 404 haven't considered yet


@api_logout.route('/3ec1buij/p3/api/v1/logout', methods=['POST'])
def api_logout_route():
	err = []
	if ("username" in session):
		session.clear()
		return jsonify(),204
	else:
		err.append({"message": "You do not have the necessary credentials for the resource"})
		return jsonify(errors = err),401
