$(document).ready(function(){
    $("#f1").submit(function(event){
        event.preventDefault();
        console.log("loginhere");
        $("#e").empty();
        var data = {"username": $("#login_username_input").val(),"password": $("#login_password_input").val()};

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            data : JSON.stringify(data),
            url: "/3ec1buij/p3/api/v1/login",
            success : function(data) {
                console.log("ajax");
                if(window.location.href.indexOf("url=") > -1)
                {
                    window.location.href = window.location.href.split("url=")[1];
                }else{
                    window.location.href = "/3ec1buij/p3/";
                }
            },

            error: function(error) {
                console.log("loginf");
                console.log("ajax");
                tmp = JSON.parse(error.responseText);
                tmp1 = tmp["errors"];
                for (var i = 0; i < tmp1.length; i++) {
                    $("#e").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
                }
            }
        });
    });
    // jQuery methods go here...

});
