
$(document).ready(function(){
    console.log("changed");
    userName = $("#sessionName").val()
    console.log(userName);
    var obj1 = {stateVariable: "begin test"};
    if(window.location.href.indexOf("album") > -1){
        console.log("album");
        var albumid = window.location.href.split("=")[1];
        history.replaceState(obj1, "title", "album?albumid=" + albumid);
        album_function(albumid,userName);
    }else if (window.location.href.indexOf("picid") > -1){
        console.log("pic");
        var picid = window.location.href.split("=")[1];
        history.replaceState(obj1, "title", "pic?picid=" + picid);
        pic_function(picid,userName);
    }

});

window.onpopstate = function(event) {
    console.log("window pop");
    if (event.state) {
        if(window.location.href.indexOf("album") > -1){
            console.log("albumpop");
            var albumid_pop = window.location.href.split("=")[1];
            album_function(albumid_pop,userName);
        }else if (window.location.href.indexOf("picid") > -1){
            console.log("picpop");
            var picid_pop = window.location.href.split("=")[1];
            var user = "";
            pic_function(picid_pop,userName);
        }
    }
}

function album_function(albumid,userName) {
    console.log("album function", albumid);
    $("#content").empty();
    $("#info").empty();
    $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: "/3ec1buij/p3/api/v1/album/" + albumid,
        success : function(data) {
            console.log("passing from api");
            $("#info").append("<p> Album title:  " + data['title'] + "</p>");
            $("#info").append("<p> Album owner:  " + data['username'] + "</p>");
            //edit?
            if (userName == data['username']) {
                console.log("usermatch");
                $("#info").append("<a href=\"/3ec1buij/p3/album/edit?albumid=" + albumid + "\"> Album Edit</a>");
            }
            var photo = data['pics'];
            for(var i = 0; i < photo.length; i++) {
                console.log("enter for loop");
                $("#content").append("<a id='pic_" + photo[i].picid + "_link'  onclick='myclick(this.id.split(\"_\")[1])'><img src='/static/images/"+photo[i].picid+"."+photo[i].format+"' width='200' height='200'> </a>");
                $("#content").append("<p>" + photo[i].date + "</p>");
                $("#content").append("<p>" + photo[i].caption + "</p>");
            }
        },
        error: function(error) {
            console.log("not passing from api");
            tmp = JSON.parse(error.responseText);
            tmp1 = tmp["errors"]
            for (var i = 0; i < tmp1.length; i++) {
                $("#content").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
            }
        }
    });
}
function myclick(picid) {
    console.log("enter myclick");
    //var picid = obj.id.split("_")[1]
    console.log(picid);
    var obj2 = {stateVariable: "clicktest"};
    history.pushState(obj2, "title", "pic?picid=" + picid);
    pic_function(picid,userName);
}
function pic_function(picid,userName){
    $("#content").empty();
    $("#info").empty();
    $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: "/3ec1buij/p3/api/v1/pic/" + picid,
        success : function(pic_data) {
            console.log("pic passing from api");
            var next = pic_data['next'];
            var prev = pic_data['prev'];
            var pic_albumid = pic_data['albumid']
            console.log(next);
            $("#content").append("<img src='/static/images/"+pic_data['picid']+"."+pic_data['format']+"'>");

            if (prev != 0) {
                $("#content").append("<p><a onclick='myclick(\"" + prev +"\")' id='prev_pic'>Prev</a></p>");
            }
            if (next != 0) {
                $("#content").append("<p><a onclick='myclick(\"" + next +"\")' id='next_pic'>Next</a></p>");
            }
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: "/3ec1buij/p3/api/v1/album/" + pic_albumid,
                success : function(album_data) {
                    console.log("pic-album fetch");
                    if (userName != album_data['username']) {
                        console.log("pic-not owner");
                        $("#content").append("<p id='pic_" + picid +"_caption'>"+pic_data['caption']+"</p>");
                    }else{
                        console.log("pic-is owner");
                        $("#content").append("modify caption: <input type='text' id='pic_caption_input' name = 'caption' value = '"+ pic_data['caption']+"'>");
                    }
                    $("#pic_caption_input").keypress(function(event1){
                        var keyCode = event1.which || event1.keyCode;
                        if (keyCode == 13) {
                            var data1 = {"albumid": pic_data['albumid'],"caption": $("#pic_caption_input").val(), "picid": pic_data['picid']};

                            $.ajax({
                                type: "PUT",
                                contentType: "application/json; charset=UTF-8",
                                url: "/3ec1buij/p3/api/v1/pic/" + picid,
                                data: JSON.stringify(data1),
                                success: function(response) {
                                    console.log("put success");
                                },
                                error: function(error) {
                                    console.log("put error");
                                    tmp = JSON.parse(error.responseText);
                                    tmp1 = tmp["errors"]
                                    for (var i = 0; i < tmp1.length; i++) {
                                        $("#content").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
                                    }
                                }
                            });
                        }
                    });
                },
                error: function(error) {
                    console.log("pic album fetch fail");
                }
            });

        },
        error: function(error) {
            console.log("pic not passing from api");
            tmp = JSON.parse(error.responseText);
            tmp1 = tmp["errors"]
            for (var i = 0; i < tmp1.length; i++) {
                $("#content").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
            }
        }
    });

}
