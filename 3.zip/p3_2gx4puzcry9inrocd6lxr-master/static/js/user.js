$(document).ready(function() {
	//New user page
	$("#new_user").submit(function(event) {
        event.preventDefault();
        $("#e_new").empty();
		console.log("enter new_user page");
		var username = document.getElementById("new_username_input").value;
        var firstname = document.getElementById("new_firstname_input").value;
        var lastname = document.getElementById("new_lastname_input").value;
        var email = document.getElementById("new_email_input").value;
        var password1 = document.getElementById("new_password1_input").value;
        var password2 = document.getElementById("new_password2_input").value;
		var mistake = false;
		if (username.length < 3) {
            $("#e_new").append("<p class='error'>Usernames must be at least 3 characters long</p>");
            mistake = true;
        }
        if (username.search(/^[\w]*$/) == -1){
            $("#e_new").append("<p class='error'>Usernames may only contain letters, digits, and underscores</p>");
            mistake = true;
        }
        if (password1.length < 8){
            $("#e_new").append("<p class='error'>Passwords must be at least 8 characters long</p>");
            mistake = true;
        }
        if (password1.search(/^(?=.*[a-zA-z])(?=.*\d)/) == -1){
            $("#e_new").append("<p class='error'>Passwords must contain at least one letter and one number</p>");
            mistake = true;
        }
        if (password1.search(/^[\w]*$/) == -1){
            $("#e_new").append("<p class='error'>Passwords may only contain letters, digits, and underscores</p>");
            mistake = true;
        }
        if (password1 != password2){
            $("#e_new").append("<p class='error'>Passwords do not match</p>");
            mistake = true;
        }
        if (email.search(/[^@]+@[^@]+\.[^@]+/) == -1){
            $("#e_new").append("<p class='error'>Email address must be valid</p>");
            mistake = true;
        }
        if (username.length > 20){
            $("#e_new").append("<p class='error'>Username must be no longer than 20 characters</p>");
            mistake = true;
        }
        if (firstname.length > 20){
            $("#e_new").append("<p class='error'>Firstname must be no longer than 20 characters</p>");
            mistake = true;
        }
        if (lastname.length > 20){
            $("#e_new").append("<p class='error'>Lastname must be no longer than 20 characters</p>");
            mistake = true;
        }
        if (email.length > 40){
            $("#e_new").append("<p class='error'>Email must be no longer than 40 characters</p>");
            mistake = true;
        }
		$.ajax({
			type: "POST",
            dataType : "json",
            contentType: "application/json; charset=utf-8",
            data : JSON.stringify({
				"username" : document.getElementById("new_username_input").value,
                "firstname" : document.getElementById("new_firstname_input").value,
                "lastname" :  document.getElementById("new_lastname_input").value,
                "email" : document.getElementById("new_email_input").value,
                "password1" : document.getElementById("new_password1_input").value,
                "password2" : document.getElementById("new_password2_input").value,
			}),
            url: "/3ec1buij/p3/api/v1/user",
			success: function(data) {
				console.log("ajax");
				window.location.href = "/3ec1buij/p3/login";
			},
			error: function(error) {
				console.log("ajax");
				tmp = JSON.parse(error.responseText);
                tmp1 = tmp["errors"];
                for (var i = 0; i < tmp1.length; i++) {
					var txt = $("#e").text();
					if (txt.indexOf(tmp1[i]["message"]) != -1)	continue;
                    $("#e_new").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
                }
			}
		})
	})
	if($("#update_user").length > 0){
		console.log("ready to get user information");
		$.ajax({
			type: "GET",
			contentType: "application/json; charset=UTF-8",
			url: "/3ec1buij/p3/api/v1/user",
			success : function(data) {
				console.log("ready to populate user information");
				$("#update_firstname_input").attr("value", data["firstname"]);
				$('#update_lastname_input').attr("value", data["lastname"]);
				$('#update_email_input').attr("value", data["email"]);
			},
			error : function(error) {
				console.log("ajax");
				tmp = JSON.parse(error.responseText);
				tmp1 = tmp["errors"];
				for (var i = 0; i < tmp1.length; i++) {
					$("#ee").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
				}
			}
		})
	}
	//User edit page
	$("#update_user").submit(function(event) {
        event.preventDefault();
        $("#ee").empty();
		console.log("enter user_edit page");
		var firstname = document.getElementById("update_firstname_input").value;
        var lastname = document.getElementById("update_lastname_input").value;
        var email = document.getElementById("update_email_input").value;
        var password1 = document.getElementById("update_password1_input").value;
        var password2 = document.getElementById("update_password2_input").value;
		var mistake = false;
		if (password1.length != 0 || password2.length !=0){
			if (password1.length < 8){
				$("#ee").append("<p class='error'>Passwords must be at least 8 characters long</p>");
				mistake = true;
			}
			if (password1.search(/^(?=.*[a-zA-z])(?=.*\d)/) == -1){
				$("#ee").append("<p class='error'>Passwords must contain at least one letter and one number</p>");
				mistake = true;
			}
			if (password1.search(/^[\w]*$/) == -1){
				$("#ee").append("<p class='error'>Passwords may only contain letters, digits, and underscores</p>");
				mistake = true;
			}
			if (password1 != password2){
				$("#ee").append("<p class='error'>Passwords do not match</p>");
				mistake = true;
			}
		}
		if (email.search(/[^@]+@[^@]+\.[^@]+/) == -1){
			$("#ee").append("<p class='error'>Email address must be valid</p>");
			mistake = true;
		}
		if (firstname.length > 20){
			$("#ee").append("<p class='error'>Firstname must be no longer than 20 characters</p>");
			mistake = true;
		}
		if (lastname.length > 20){
			$("#ee").append("<p class='error'>Lastname must be no longer than 20 characters</p>");
			mistake = true;
		}
		if (email.length > 40){
			$("#ee").append("<p class='error'>Email must be no longer than 40 characters</p>");
			mistake = true;
		}
		if (mistake == false){
			$.ajax({
				type: "PUT",
				contentType: "application/json; charset=UTF-8",
				data: JSON.stringify({
					"firstname" : document.getElementById("update_firstname_input").value,
					"lastname" :  document.getElementById("update_lastname_input").value,
					"email" : document.getElementById("update_email_input").value,
					"password1" : document.getElementById("update_password1_input").value,
					"password2" : document.getElementById("update_password2_input").value
				}),
				url: "/3ec1buij/p3/api/v1/user",
				success : function(data) {
					console.log("ajax");
					console.log("update user information successfully");
					$("#user_info").empty();
					$("#user_info").append("Logged in as: ", document.getElementById("update_firstname_input").value, ' ', document.getElementById("update_lastname_input").value);
					//window.location.replace("/3ec1buij/p3/user/edit");
				},
				error : function(error) {
					console.log("ajax");
					tmp = JSON.parse(error.responseText);
					tmp1 = tmp["errors"];
					for (var i = 0; i < tmp1.length; i++) {
						$("#ee").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
					}
				}
			});
		}
	})
})
