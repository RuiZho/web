$(document).ready(function(){
    $("#nav_logout").click(function(event){
        event.preventDefault();
        console.log("logout");
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/3ec1buij/p3/api/v1/logout",
            success : function(data) {
                console.log("ajax");
                window.location.href = "/3ec1buij/p3/";
            },
            error: function(error) {
                console.log("ajax");
                console.log("logoutf");
                tmp = JSON.parse(error.responseText);
                tmp1 = tmp["errors"]
                for (var i = 0; i < tmp1.length; i++) {
                    $("#logout_error").append("<p class='error'>" + tmp1[i]["message"] + "</p>");
                }
            }
        });
    });
});
