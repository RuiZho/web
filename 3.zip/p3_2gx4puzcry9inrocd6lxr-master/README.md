# EECS 485 Project 3 Client Side Dynamic Pages

## Group 11

## Contributions:
### Feiyang Liu: user, user edit
### Rui Zhou: album/pic, login/logout
ruizhou agreed upon contribution

fyliu agreed upon contribution
