from flask import *
from extensions import *
from config import *

from extensions import *

from config import *

pic = Blueprint('pic', __name__, template_folder='templates')

@pic.route('/3ec1buij/p3/pic', methods=['GET', 'POST','PUT'])
def pic_route():
	return render_template("album.html")
