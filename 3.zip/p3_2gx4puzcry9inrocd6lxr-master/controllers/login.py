from flask import *

from extensions import *

from config import *

import os, sys
import hashlib
import uuid
login = Blueprint('login', __name__, template_folder='templates')

# Page 404 haven't considered yet


@login.route('/3ec1buij/p3/login', methods=['GET'])
def login_route():
	if ('username' in session):
		return redirect('/3ec1buij/p3/user/edit')
	return render_template("login.html")
