from flask import *

from extensions import *

from config import *

import hashlib, uuid

import re, os

user = Blueprint('user', __name__, template_folder='templates')
@user.route('/3ec1buij/p3/user', methods = ['GET','POST'])
def user_route():
	# If already login, redirect to user/edit;
	if 'username' in session:
		return redirect('/3ec1buij/p3/user/edit')
	return render_template('user.html')
@user.route('/3ec1buij/p3/user/edit', methods = ['GET','POST'])
def edit_user():
	if 'username' not in session:
		return redirect("/3ec1buij/p3/login")
	return render_template('user.html')
