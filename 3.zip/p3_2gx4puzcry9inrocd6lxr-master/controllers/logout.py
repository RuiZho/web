from flask import *

from extensions import *

from config import *

import os, sys

logout = Blueprint('logout', __name__, template_folder='templates')

# Page 404 haven't considered yet


@logout.route('/3ec1buij/p3/logout', methods=['GET', 'POST'])
def logout_route():
	#session.clear()
	return redirect("/3ec1buij/p3")
