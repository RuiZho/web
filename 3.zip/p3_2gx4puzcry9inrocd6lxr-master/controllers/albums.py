from flask import *

from extensions import *

from config import *

import os, sys

albums = Blueprint('albums', __name__, template_folder='templates')

@albums.route('/3ec1buij/p3/albums')
def albums_route():
	if ('username' in session) and (not request.args.get('username')):
		login = True
		reque = False
		user = session['username']
		db = connect_to_database()
		cur = db.cursor()
		cur.execute('SELECT firstname, lastname FROM User WHERE username = \'%s\'' % (user))
		user_info = cur.fetchall()
		login_firstname = user_info[0]['firstname']
		login_lastname = user_info[0]['lastname']
		cur.execute('SELECT albumid, title, username FROM Album WHERE username = \'%s\'' % (user))
		results = cur.fetchall()
		grantedAlbums = None
	else:
		db = connect_to_database()
		cur = db.cursor()
		if ('username' in session):
			login = True
			user = session['username']
			cur.execute('SELECT firstname, lastname FROM User WHERE username = \'%s\'' % (user))
			user_info = cur.fetchall()
			login_firstname = user_info[0]['firstname']
			login_lastname = user_info[0]['lastname']
			cur.execute('SELECT A.albumid, B.title FROM AlbumAccess A, Album B WHERE A.albumid = B.albumid AND A.username = \'%s\'' % (user))
			grantedAlbums = cur.fetchall()
		else:
			login = False
			login_firstname = ''
			login_lastname = ''
			grantedAlbums = None

		if (not request.args.get('username')):
			return redirect('/3ec1buij/p3/login')
		else:
			reque = True;
		user = request.args.get('username')
		rows_count = cur.execute('SELECT password FROM User WHERE username = \'%s\'' % (user))
		if rows_count == 0:
			abort(404)
		cur.execute('SELECT albumid, title, username FROM Album WHERE username = \'%s\' AND access = \'public\'' % (user))
		results = cur.fetchall()
	options = {
		'login': login,
		'reque': reque,
		'firstname': login_firstname,
		'lastname': login_lastname,
		'host': config.env['host'],
		'user': user,
		"edit": False,
		'port': config.env['port'],
		'results': results,
		'grantedAlbums': grantedAlbums
	}
	return render_template("albums.html", **options)




@albums.route('/3ec1buij/p3/albums/edit', methods=['GET', 'POST'])
def albums_edit_route():
	op = request.form.get('op')
	db = connect_to_database()
	cur = db.cursor()
	if ('username' not in session):
		return redirect('/3ec1buij/p3/login')
	user = session['username']
	if(request.args.get('username')):
		if request.args.get('username') == user:
			return redirect('/3ec1buij/p3/albums/edit')
		else:
			abort(403)
	cur.execute('SELECT firstname, lastname FROM User WHERE username = \'%s\'' % (user))
	user_info = cur.fetchall()
	login_firstname = user_info[0]['firstname']
	login_lastname = user_info[0]['lastname']

	if request.method == 'POST':
		if op == "add":
			username = request.form.get('username')
			title = request.form.get('title')
			cur.execute('INSERT INTO Album (title, username, created, lastupdated, access) VALUES (\'%s\', \'%s\', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, \'private\')' % (title, user))
		elif op == "delete":
			albumid = request.form.get('albumid')
			cur.execute('SELECT picid FROM Contain WHERE albumid = %s' % albumid)
			pic = cur.fetchall()
			for pic_id in pic:
				cur.execute('SELECT format FROM Photo WHERE picid = \'%s\'' % (str(pic_id['picid'])))
				format_f = cur.fetchall()
				os.remove(os.path.join('static/images/', str(pic_id['picid']) + "." + str(format_f[0]['format'])))
			cur.execute('DELETE FROM Album WHERE albumid = %s' % albumid)
	rows_count = cur.execute('SELECT password FROM User WHERE username = \'%s\'' % (user))
	if rows_count == 0:
		abort(404)
	cur.execute('SELECT albumid, title, username FROM Album WHERE username = \'%s\'' % (user))
	results = cur.fetchall()
	options = {
		'firstname': login_firstname,
		'lastname': login_lastname,
		'login': True,
		'host': config.env['host'],
		'user': user,
		"edit": True,
		'port': config.env['port'],
		'results': results
	}
	return render_template("albums.html", **options)
