from flask import *

from extensions import *

from config import *

main = Blueprint('main', __name__, template_folder='templates')

@main.route('/3ec1buij/p3/')
def main_route():
    db = connect_to_database()
    cur = db.cursor()
    cur.execute('SELECT username FROM User')
    results = cur.fetchall()
    cur.execute('SELECT albumid, title FROM Album WHERE access=\'public\'')
    publicAlbums = cur.fetchall()
    if 'username' in session:
        username = session['username']
        login = True;
        cur.execute('SELECT albumid, title FROM Album WHERE access=\'private\' AND username = \'%s\'' % (username))
        privateAlbums = cur.fetchall()
        cur.execute('SELECT firstname,lastname FROM User WHERE username = \'%s\'' % (username))
        name = cur.fetchall()
        firstname = name[0]['firstname']
        lastname = name[0]['lastname']
        cur.execute('SELECT A.albumid, B.title FROM AlbumAccess A, Album B WHERE A.albumid = B.albumid AND A.username = \'%s\'' % (username))
        grantedAlbums = cur.fetchall()
    else:
        login=False;
        privateAlbums=[];
        grantedAlbums=[];
        firstname = '';
        lastname = '';
    options = {
    'host': config.env['host'],
    'port': config.env['port'],
    'results': results,
    'publicAlbums':publicAlbums,
    'privateAlbums':privateAlbums,
    'grantedAlbums':grantedAlbums,
    'firstname':firstname,
    'lastname':lastname,
    'login':login
    }
    return render_template("base.html", **options)
